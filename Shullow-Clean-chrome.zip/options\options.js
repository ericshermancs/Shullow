// Options JavaScript for Map POI Injector
// Handles settings and data management in the options page